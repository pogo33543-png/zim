import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// این کلاینت با service-role کار می‌کنه یعنی از RLS رد می‌شه — فقط سمت سرور استفاده می‌شه، هیچوقت به مرورگر نره
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

function slugify(q) {
  return q.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\p{L}\p{N}-]/gu, '').slice(0, 80) || 'q-' + Date.now();
}

export async function POST(req) {
  const { question, askerId } = await req.json();
  if (!question || !question.trim()) {
    return NextResponse.json({ error: 'سوال خالیه' }, { status: 400 });
  }

  const slug = slugify(question);

  const { data: existing } = await supabaseAdmin
    .from('questions')
    .select('id')
    .eq('slug', slug)
    .maybeSingle();

  if (existing) {
    return NextResponse.json({ questionId: existing.id, reused: true });
  }

  const { data: newQ, error: qErr } = await supabaseAdmin
    .from('questions')
    .insert({ question, slug, asker_id: askerId || null })
    .select()
    .single();

  if (qErr) return NextResponse.json({ error: qErr.message }, { status: 500 });

  let text = 'نتونستم جواب بدم.';
  let blocked = false;

  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 300,
        system:
          'تو کاجو هستی، ربات یه اپ فارسی به اسم «دفترچه راهنمای زندگی». فقط فکت بده، هیچ‌وقت عقیده‌ی شخصی نده. اگه سوال نامناسب/مضر بود، مودبانه و کوتاه رد کن. جواب فقط فارسی، حداکثر ۳ جمله. اگه رد شد، جواب رو با [REJECTED] شروع کن.',
        messages: [{ role: 'user', content: question }]
      })
    });
    const data = await resp.json();
    text = (data.content || []).map((c) => c.text || '').join(' ').trim() || text;
    if (text.startsWith('[REJECTED]')) {
      blocked = true;
      text = text.replace('[REJECTED]', '').trim();
    }
  } catch (e) {
    text = 'اتصال به هوش مصنوعی برقرار نشد.';
  }

  await supabaseAdmin.from('answers').insert({
    question_id: newQ.id,
    text,
    type: 'ai',
    blocked
  });

  return NextResponse.json({ questionId: newQ.id, reused: false });
}
