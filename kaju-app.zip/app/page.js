'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useNotifications } from '../lib/useNotifications';
import Header from '../components/Header';
import Hero from '../components/Hero';
import SectionsTrail from '../components/SectionsTrail';
import QA from '../components/QA';
import Tasks from '../components/Tasks';
import Calendar from '../components/Calendar';
import { SeasonBandTop, SeasonBandBottom } from '../components/SeasonBands';

export default function Page() {
  const [age, setAge] = useState('adult');
  const [user, setUser] = useState(null);
  const [notifOpen, setNotifOpen] = useState(false);
  const { notifications, refresh, markSeen } = useNotifications(user);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user || null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user || null));
    return () => sub.subscription.unsubscribe();
  }, []);

  function handleBell(notifItem) {
    if (notifItem && notifItem.id) {
      markSeen(notifItem.id, notifItem.total);
      return;
    }
    setNotifOpen((o) => {
      if (!o) refresh();
      return !o;
    });
  }

  return (
    <>
      <SeasonBandTop />
      <Header
        age={age}
        setAge={setAge}
        user={user}
        notifications={notifications}
        notifPanelOpen={notifOpen}
        onOpenNotif={handleBell}
      />
      <Hero age={age} />
      <SectionsTrail age={age} />
      <div className="wrap">
        <QA user={user} />
        <Tasks user={user} />
        <Calendar />
      </div>
      <SeasonBandBottom />
      <footer>نسخه‌ی واقعی — با گوگل، دیتابیس مشترک و هوش مصنوعی زنده.</footer>
    </>
  );
}
