import './globals.css';

export const metadata = {
  title: 'دفترچه راهنمای زندگی',
  description: 'کتابخانه، بازی، کار، مالی، کنجکاوی، آشپزی، سرگرمی و کودکان — همراه با کاجو'
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
