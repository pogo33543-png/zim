# دفترچه راهنمای زندگی (کاجو) — راهنمای کامل دیپلوی

این پروژه یه اپ Next.js واقعیه که با Supabase (دیتابیس + ورود با گوگل) و Anthropic API کار می‌کنه.
پایین، مرحله‌به‌مرحله، از صفر تا سایت زنده روی اینترنت.

---

## ۱. ساخت حساب گیت‌هاب

1. برو به [github.com](https://github.com) و روی **Sign up** بزن.
2. یه ایمیل، پسورد و یوزرنیم وارد کن و مراحل تأیید رو کامل کن.
3. بعد از ساخت حساب، بالای صفحه روی **+** بعد **New repository** بزن.
   - اسم رپو: `kaju-life-guide` (یا هر اسمی)
   - Public یا Private فرقی نداره
   - **Create repository**
4. حالا باید فایل‌های این پروژه رو توش آپلود کنی. ساده‌ترین راه:
   - همین صفحه‌ی رپوی خالی یه لینک "uploading an existing file" داره — کلیک کن و کل پوشه‌ی این پروژه رو بکش و ول کن، بعد **Commit changes**.
   - (اگه بعداً راحت‌تر شدی، می‌تونی Git رو نصب کنی و با `git init / git add . / git commit / git push` کار کنی — ولی برای شروع همون آپلود مستقیم کافیه.)

---

## ۲. ساخت پروژه در Supabase (دیتابیس + ورود با گوگل)

1. برو به [supabase.com](https://supabase.com) → **Start your project** → با گیت‌هاب یا ایمیل وارد شو.
2. **New project** بزن، یه اسم و پسورد دیتابیس انتخاب کن، منطقه (Region) رو نزدیک‌ترین به خودت بذار.
3. بعد از ساخته‌شدن پروژه (چند دقیقه طول می‌کشه)، از منوی سمت چپ برو به **SQL Editor**.
4. کل محتوای فایل `supabase/schema.sql` (همین پروژه) رو کپی کن، توی SQL Editor پیست کن و **Run** بزن.
   این کار جدول‌های سوال/جواب/رأی/کارها/رشد رو می‌سازه و قوانین امنیتی (RLS) رو فعال می‌کنه.
5. از منوی چپ برو به **Project Settings → API**. سه مقدار رو یادداشت کن:
   - `Project URL` → همون `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → همون `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key (زیر «Reveal») → همون `SUPABASE_SERVICE_ROLE_KEY` (این یکی خیلی محرمانه‌ست، فقط سمت سرور استفاده می‌شه)

---

## ۳. ساخت Google OAuth (برای دکمه‌ی «ورود با گوگل»)

1. برو به [console.cloud.google.com](https://console.cloud.google.com) و یه پروژه‌ی جدید بساز.
2. از منو: **APIs & Services → OAuth consent screen** → نوع External رو انتخاب کن و اطلاعات پایه (اسم اپ، ایمیل) رو پر کن.
3. برو به **APIs & Services → Credentials → Create Credentials → OAuth client ID**.
   - Application type: **Web application**
   - Authorized redirect URIs: آدرس زیر رو بذار (پروژه‌ی سوپابیسِت رو جاش بذار):
     ```
     https://YOUR-PROJECT.supabase.co/auth/v1/callback
     ```
     (این آدرس دقیق رو از Supabase → Authentication → Providers → Google هم می‌تونی کپی کنی)
4. بعد از ساخت، یه **Client ID** و **Client Secret** بهت می‌ده — یادداشت کن.
5. برگرد به Supabase → **Authentication → Providers → Google** → فعالش کن و Client ID/Secret رو وارد کن → **Save**.
6. توی همون بخش Authentication، برو به **URL Configuration** و آدرس سایتت (بعد از دیپلوی روی Vercel می‌گیریش، فعلاً می‌تونی `http://localhost:3000` بذاری و بعداً اضافه کنی) رو به **Redirect URLs** اضافه کن.

---

## ۴. گرفتن کلید Anthropic API

1. برو به [console.anthropic.com](https://console.anthropic.com) و وارد شو یا ثبت‌نام کن.
   *(این حساب جدا از حساب Claude.ai‌ته و ممکنه نیاز به شارژ اعتبار داشته باشه.)*
2. از بخش **API Keys**، یه کلید جدید بساز و کپی کن → همون `ANTHROPIC_API_KEY`.

---

## ۵. دیپلوی روی Vercel

1. برو به [vercel.com](https://vercel.com) → **Sign up** → با همون حساب گیت‌هابت وارد شو.
2. **Add New → Project** → رپوی `kaju-life-guide` رو از گیت‌هاب انتخاب کن → **Import**.
3. قبل از **Deploy**، بخش **Environment Variables** رو باز کن و این چهارتا رو اضافه کن:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   SUPABASE_SERVICE_ROLE_KEY=...
   ANTHROPIC_API_KEY=...
   ```
4. **Deploy** بزن. بعد چند دقیقه یه آدرس مثل `kaju-life-guide.vercel.app` بهت می‌ده — سایتت زنده‌ست! 🌲

---

## ۶. آخرین تنظیم: وصل کردن آدرس نهایی

بعد از گرفتن آدرس Vercel:
1. برگرد به Supabase → Authentication → URL Configuration → آدرس Vercel رو به **Redirect URLs** اضافه کن.
2. برگرد به Google Cloud Console → Credentials → همون OAuth client → آدرس Vercel رو هم به **Authorized JavaScript origins** اضافه کن.

بعد از این دو تا، دکمه‌ی «ورود با گوگل» روی سایت زنده‌ت هم کار می‌کنه.

---

## نکات

- هر تغییری که توی کدت بدی و به گیت‌هاب push/آپلود کنی، Vercel خودش دوباره دیپلوی می‌کنه.
- اگه چیزی کار نکرد، اول Console مرورگر (F12) رو چک کن — معمولاً خطای env variable یا RLS اونجا معلومه.
- امتیازدهی الان از طریق جدول `votes` با یه trigger توی دیتابیس محاسبه می‌شه؛ هر کاربر فقط یه رأی روی هر جواب داره (رأی جدید رأی قبلی‌شو جایگزین می‌کنه).
