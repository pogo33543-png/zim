'use client';
import { useMemo } from 'react';

function getSeason() {
  const m = new Date().getMonth() + 1;
  if ([3, 4, 5].includes(m)) return { key: 'spring', label: 'بهار', emojis: ['🌸', '🌷', '🌱'] };
  if ([6, 7, 8].includes(m)) return { key: 'summer', label: 'تابستان', emojis: ['🍃', '☀️', '🌿'] };
  if ([9, 10, 11].includes(m)) return { key: 'autumn', label: 'پاییز', emojis: ['🍂', '🍁', '🌾'] };
  return { key: 'winter', label: 'زمستان', emojis: ['❄️', '🌨️', '✨'] };
}

function Band({ position, season }) {
  const drifts = useMemo(
    () =>
      Array.from({ length: 10 }).map((_, i) => ({
        left: Math.random() * 100,
        delay: Math.random() * 6,
        dur: 5 + Math.random() * 4,
        emoji: season.emojis[Math.floor(Math.random() * season.emojis.length)],
        key: i
      })),
    [season]
  );
  return (
    <div className={`season-band ${position}`}>
      <div className="season-label">{season.label}</div>
      {drifts.map((d) => (
        <span
          key={d.key}
          className="drift"
          style={{ left: `${d.left}%`, animationDuration: `${d.dur}s`, animationDelay: `${d.delay}s` }}
        >
          {d.emoji}
        </span>
      ))}
    </div>
  );
}

export function SeasonBandTop() {
  const season = getSeason();
  return <Band position="top" season={season} />;
}
export function SeasonBandBottom() {
  const season = getSeason();
  return <Band position="bottom" season={season} />;
}
