'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import Kaju from './Kaju';

const AGE_LABELS = { young: '۷-۱۲', 'teen-mid': '۱۲-۱۵', 'teen-old': '۱۵-۱۸', adult: '+۱۸' };

export default function Header({ age, setAge, user, notifications, onOpenNotif, notifPanelOpen }) {
  async function login() {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: typeof window !== 'undefined' ? window.location.origin : undefined }
    });
  }
  async function logout() {
    await supabase.auth.signOut();
  }

  return (
    <header className="topbar">
      <div className="brand">
        <Kaju size={32} tilt={-8} />
        <span>دفترچه راهنمای زندگی</span>
      </div>

      <div className="age-pills">
        {Object.keys(AGE_LABELS).map((a) => (
          <button
            key={a}
            className={`age-pill ${age === a ? 'active' : ''}`}
            onClick={() => setAge(a)}
          >
            {AGE_LABELS[a]}
          </button>
        ))}
      </div>

      <div className="header-right">
        <button className="bell-btn" onClick={onOpenNotif}>
          🔔
          {notifications.length > 0 && <span className="bell-badge">{notifications.length}</span>}
        </button>
        {notifPanelOpen && (
          <div className="notif-panel">
            {notifications.length === 0 ? (
              <div className="notif-empty">اعلان جدیدی نیست</div>
            ) : (
              notifications.map((n) => (
                <div key={n.id} className="notif-item" onClick={() => onOpenNotif(n)}>
                  سوالت جواب گرفت: «{n.question}»
                </div>
              ))
            )}
          </div>
        )}

        {user ? (
          <button className="google-btn" onClick={logout}>
            خروج ({user.email?.split('@')[0]})
          </button>
        ) : (
          <button className="google-btn" onClick={login}>
            ورود با گوگل
          </button>
        )}
      </div>
    </header>
  );
}
