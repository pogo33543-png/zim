'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function QA({ user }) {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(false);
  const [openMore, setOpenMore] = useState({});
  const [replyText, setReplyText] = useState({});

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const { data } = await supabase
      .from('questions')
      .select('id, question, created_at, answers(id, text, type, votes, blocked)')
      .order('created_at', { ascending: false });
    setItems(data || []);
  }

  async function ask(e) {
    e.preventDefault();
    if (!q.trim()) return;
    setLoading(true);
    await fetch('/api/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: q.trim(), askerId: user ? user.id : null })
    });
    setQ('');
    await load();
    setLoading(false);
  }

  async function vote(answerId, dir) {
    if (!user) {
      alert('برای رأی دادن اول با گوگل وارد شو.');
      return;
    }
    // upsert روی votes؛ trigger توی دیتابیس شمارش votes رو خودش آپدیت می‌کنه
    await supabase.from('votes').upsert({ answer_id: answerId, user_id: user.id, dir }, { onConflict: 'answer_id,user_id' });
    await load();
  }

  async function submitAnswer(questionId) {
    const text = (replyText[questionId] || '').trim();
    if (!text) return;
    if (!user) {
      alert('برای جواب دادن اول با گوگل وارد شو.');
      return;
    }
    await supabase.from('answers').insert({ question_id: questionId, author_id: user.id, text, type: 'human' });
    setReplyText((r) => ({ ...r, [questionId]: '' }));
    await load();
  }

  return (
    <div className="panel">
      <h2 className="h2">🤔 بپرس و جواب بگیر</h2>
      <form className="qa-form" onSubmit={ask}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="سوالت رو بنویس..." maxLength={200} />
        <button type="submit" disabled={loading}>
          {loading ? '...' : 'بپرس'}
        </button>
      </form>

      {items.length === 0 && <div className="qa-empty">هنوز سوالی پرسیده نشده 🌱</div>}

      {items.slice(0, 8).map((it) => {
        const answers = [...(it.answers || [])].sort((a, b) => (b.votes || 0) - (a.votes || 0));
        const top = answers[0] || { text: 'هنوز جوابی نیست.', votes: 0, type: 'ai' };
        const rest = answers.slice(1);
        return (
          <div key={it.id} className="qa-item">
            <div className="q">❓ {it.question}</div>
            <div className={`a ${top.blocked ? 'blocked' : ''}`}>
              {top.text}
              <span className="answer-badge">{top.type === 'human' ? '🧑 پاسخ یه کاربر' : '🤖 پاسخ هوش مصنوعی'}</span>
            </div>
            <div className="vote-row">
              <button className="vote-btn" onClick={() => vote(top.id, 1)}>▲</button>
              <span>{top.votes || 0}</span>
              <button className="vote-btn" onClick={() => vote(top.id, -1)}>▼</button>
              {rest.length > 0 && (
                <button className="more-toggle" onClick={() => setOpenMore((s) => ({ ...s, [it.id]: !s[it.id] }))}>
                  پاسخ‌های دیگه ({rest.length})
                </button>
              )}
            </div>
            {openMore[it.id] && (
              <div className="more-answers">
                {rest.map((a) => (
                  <div key={a.id} className="qa-sub">
                    {a.text} <span className="answer-badge">{a.type === 'human' ? '🧑' : '🤖'}</span>
                    <div className="vote-row">
                      <button className="vote-btn" onClick={() => vote(a.id, 1)}>▲</button>
                      <span>{a.votes || 0}</span>
                      <button className="vote-btn" onClick={() => vote(a.id, -1)}>▼</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <form
              className="human-answer-form"
              onSubmit={(e) => {
                e.preventDefault();
                submitAnswer(it.id);
              }}
            >
              <input
                value={replyText[it.id] || ''}
                onChange={(e) => setReplyText((r) => ({ ...r, [it.id]: e.target.value }))}
                placeholder="یه جواب دیگه بنویس..."
                maxLength={240}
              />
              <button type="submit">ثبت</button>
            </form>
          </div>
        );
      })}
      {!user && <div className="login-hint">برای رأی دادن یا جواب دادن، اول با گوگل وارد شو.</div>}
    </div>
  );
}
