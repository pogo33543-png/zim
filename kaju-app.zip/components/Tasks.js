'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import Kaju from './Kaju';

export default function Tasks({ user }) {
  const [tasks, setTasks] = useState([]);
  const [growth, setGrowth] = useState({ rings: 0, leaf_positions: [] });
  const [input, setInput] = useState('');

  useEffect(() => {
    if (!user) return;
    load();
  }, [user]);

  async function load() {
    const { data: t } = await supabase.from('tasks').select('*').eq('user_id', user.id).order('created_at');
    setTasks(t || []);
    const { data: g } = await supabase.from('growth').select('*').eq('user_id', user.id).maybeSingle();
    if (g) setGrowth(g);
    else {
      await supabase.from('growth').insert({ user_id: user.id, rings: 0, leaf_positions: [] });
    }
  }

  async function addTask(e) {
    e.preventDefault();
    if (!input.trim() || !user) return;
    const { data } = await supabase.from('tasks').insert({ user_id: user.id, text: input.trim(), done: false }).select().single();
    setTasks((prev) => [...prev, data]);
    setInput('');
  }

  async function toggleTask(task) {
    const done = !task.done;
    await supabase.from('tasks').update({ done }).eq('id', task.id);
    setTasks((prev) => prev.map((t) => (t.id === task.id ? { ...t, done } : t)));
    if (done) addLeaf();
  }

  async function addLeaf() {
    const angle = Math.random() * Math.PI * 2;
    const r = 18 + Math.random() * 22;
    const pos = [50 + Math.cos(angle) * r, 40 + Math.sin(angle) * r * 0.7];
    const next = [...(growth.leaf_positions || []), pos];
    setGrowth((g) => ({ ...g, leaf_positions: next }));
    await supabase.from('growth').update({ leaf_positions: next }).eq('user_id', user.id);
  }

  async function learnSomething() {
    const rings = (growth.rings || 0) + 1;
    setGrowth((g) => ({ ...g, rings }));
    await supabase.from('growth').update({ rings }).eq('user_id', user.id);
  }

  if (!user) {
    return (
      <div className="panel">
        <h2 className="h2">✅ کارهای امروز</h2>
        <div className="qa-empty">برای ثبت کارها اول با گوگل وارد شو 🌱</div>
      </div>
    );
  }

  return (
    <div className="panel">
      <h2 className="h2">✅ کارهای امروز</h2>
      <form className="task-form" onSubmit={addTask}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="یه کار جدید..."
          maxLength={80}
        />
        <button type="submit">+</button>
      </form>
      <ul className="task-list">
        {tasks.length === 0 && <li style={{ opacity: 0.5, background: 'none' }}>هنوز کاری اضافه نکردی</li>}
        {tasks.map((t) => (
          <li key={t.id} className={t.done ? 'done' : ''}>
            <input type="checkbox" checked={t.done} onChange={() => toggleTask(t)} />
            <span>{t.text}</span>
          </li>
        ))}
      </ul>
      <button className="learn-btn" onClick={learnSomething}>
        📚 یه چیز جدید یاد گرفتم
      </button>
      <div className="tree-canvas-wrap">
        <Kaju size={130} tilt={-4} extraLeaves={growth.leaf_positions || []} rings={growth.rings || 0} />
      </div>
    </div>
  );
}
