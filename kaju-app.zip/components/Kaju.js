'use client';

export default function Kaju({ size = 120, tilt = -5, extraLeaves = [], rings = 0 }) {
  const leafDots = extraLeaves
    .map(([x, y], i) => `<circle key="${i}" cx="${x}" cy="${y}" r="4" fill="#F0A8C2" opacity="0.9"/>`)
    .join('');
  let ringMarks = '';
  for (let i = 0; i < rings; i++) {
    ringMarks += `<circle cx="50" cy="100" r="${4 + i * 2.4}" fill="none" stroke="#D9B36C" stroke-width="1" opacity="0.6"/>`;
  }

  const svg = `
    <g transform="rotate(${tilt} 50 100)">
      <ellipse cx="50" cy="108" rx="15" ry="4" fill="#000" opacity="0.2"/>
      <ellipse cx="42" cy="101" rx="6" ry="8.5" fill="#173A2B"/>
      <ellipse cx="58" cy="101" rx="6" ry="8.5" fill="#173A2B"/>
      <path d="M50 28 C30 28 25 54 34 62 C23 66 26 85 41 87 C35 97 46 105 50 105 C54 105 65 97 59 87 C74 85 77 66 66 62 C75 54 70 28 50 28 Z" fill="#3E6B49"/>
      <path d="M50 44 C37 44 34 60 40 66 C33 70 37 81 46 83 C50 87 54 87 58 83 C67 81 71 70 64 66 C70 60 63 44 50 44 Z" fill="#6FA36E"/>
      <circle cx="43" cy="65" r="4" fill="#0E1F17"/>
      <circle cx="57" cy="65" r="4" fill="#0E1F17"/>
      <circle cx="44.2" cy="63.7" r="1.1" fill="#fff"/>
      <circle cx="58.2" cy="63.7" r="1.1" fill="#fff"/>
      <path d="M34 62 Q19 58 15 66" stroke="#3E6B49" stroke-width="4" fill="none" stroke-linecap="round"/>
      <circle cx="14" cy="67" r="4.5" fill="#A9D6A0"/>
    </g>
    ${leafDots}
    ${ringMarks}
  `;

  return (
    <svg
      width={size}
      height={size * 1.15}
      viewBox="0 0 100 130"
      className="kaju-svg"
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
}
