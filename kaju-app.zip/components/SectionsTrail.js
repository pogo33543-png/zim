'use client';

const ALL_SECTIONS = [
  { id: 'book', icon: '📚', title: 'کتابخانه', color: '#3E6B49' },
  { id: 'game', icon: '🎲', title: 'بازی', color: '#4FA69A' },
  { id: 'work', icon: '💼', title: 'کار', color: '#5A3E2B' },
  { id: 'finance', icon: '💰', title: 'مالی', color: '#D9B36C' },
  { id: 'curiosity', icon: '🔍', title: 'کنجکاوی', color: '#6FA36E' },
  { id: 'cooking', icon: '🍳', title: 'آشپزی', color: '#E88AAE' },
  { id: 'fun', icon: '🎬', title: 'سرگرمی', color: '#F0A8C2' },
  { id: 'kids', icon: '🧸', title: 'کودکان', color: '#A9D6A0' }
];

function sectionsForAge(age) {
  if (age === 'young') return ALL_SECTIONS.filter((s) => !['work', 'finance', 'cooking'].includes(s.id));
  if (age === 'teen-mid') return ALL_SECTIONS.filter((s) => s.id !== 'work');
  return ALL_SECTIONS;
}

export default function SectionsTrail({ age }) {
  const list = sectionsForAge(age);
  return (
    <div className="wrap">
      <h2 className="h2">🌲 بخش‌ها</h2>
      <div className="trail-wrap">
        {list.map((s, i) => (
          <div key={s.id} className={`trail-item ${i % 2 === 0 ? 'odd' : 'even'}`}>
            <div className="label">{s.title}</div>
            <div className="node" style={{ background: s.color }}>
              {s.icon}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
