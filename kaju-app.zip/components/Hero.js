'use client';
import { useEffect, useState } from 'react';
import Kaju from './Kaju';

const SPEECH_BY_AGE = {
  young: ['سلام! بیا بازی کنیم و یاد بگیریم 🌱', 'امروز یه کار کوچیک تموم کنیم؟', 'هورا! تو خیلی خفنی 🌟'],
  'teen-mid': ['سلام! امروز چیکار داری؟', 'یه قدم کوچیک بردار، من همینجام 🌿', 'هر روز یکم رشد کن، عجله نکن'],
  'teen-old': ['سلام، آماده‌ای یه چیز جدید یاد بگیری؟', 'مسیرت مال خودته، فقط شروع کن', 'امروز رو با یه هدف کوچیک ببند'],
  adult: ['سلام. هر روز یه حلقه‌ی جدیده', 'یه کار مشخص، همین امروز', 'پیشرفت آرومم پیشرفته']
};

export default function Hero({ age }) {
  const [speech, setSpeech] = useState('');
  useEffect(() => {
    const arr = SPEECH_BY_AGE[age] || SPEECH_BY_AGE.adult;
    setSpeech(arr[Math.floor(Math.random() * arr.length)]);
  }, [age]);

  return (
    <section className="hero">
      <div className="speech">{speech}</div>
      <Kaju size={120} tilt={-5} />
      <h1>
        یه دفترچه‌ی <span>زنده</span> برای زندگی روزمره‌ات
      </h1>
    </section>
  );
}
