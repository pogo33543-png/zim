'use client';
import { useMemo } from 'react';

function toJalali(gy, gm, gd) {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy;
  gy = gm > 2 ? gy + 1 : gy;
  let days = 355666 + 365 * gy + Math.floor((gy + 8) / 4) - Math.floor((gy + 99) / 100) + Math.floor((gy + 399) / 400) + gd + g_d_m[gm - 1];
  jy = -1595 + 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let jm, jd;
  if (days < 186) {
    jm = 1 + Math.floor(days / 31);
    jd = 1 + (days % 31);
  } else {
    jm = 7 + Math.floor((days - 186) / 30);
    jd = 1 + ((days - 186) % 30);
  }
  return [jy, jm, jd];
}

const J_MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const RING_COLORS = ['#6B4A34', '#7A5A3F', '#8C6B48', '#A9D6A0'];

export default function Calendar() {
  const { gregorian, jalali, jy } = useMemo(() => {
    const now = new Date();
    const [jy, jm, jd] = toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
    return {
      gregorian: now.toLocaleDateString('en-GB', { year: 'numeric', month: 'long', day: 'numeric' }),
      jalali: `${jd} ${J_MONTHS[jm - 1]} ${jy}`,
      jy
    };
  }, []);

  const rings = [];
  for (let i = 8; i >= 1; i--) {
    rings.push(
      <circle
        key={i}
        cx="50"
        cy="50"
        r={i * 5.2}
        fill="none"
        stroke={RING_COLORS[i % 4]}
        strokeWidth="1.4"
        opacity={0.35 + i * 0.05}
      />
    );
  }

  return (
    <div className="panel cal-widget">
      <svg width="86" height="86" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="46" fill="#3E2A1C" />
        {rings}
        <text x="50" y="55" textAnchor="middle" fontSize="13" fill="#F5F0E3" fontWeight="700">
          {jy}
        </text>
      </svg>
      <div className="cal-dates">
        <div className="g">{gregorian}</div>
        <div className="j">{jalali}</div>
      </div>
    </div>
  );
}
