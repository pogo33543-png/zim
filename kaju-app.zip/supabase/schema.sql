-- این کوئری رو داخل Supabase > SQL Editor اجرا کن (یکبار، کل فایل رو کپی/پیست کن)

create extension if not exists "uuid-ossp";

create table if not exists profiles (
  id uuid references auth.users on delete cascade primary key,
  age_group text default 'adult',
  created_at timestamptz default now()
);

create table if not exists questions (
  id uuid default uuid_generate_v4() primary key,
  asker_id uuid references auth.users,
  question text not null,
  slug text unique not null,
  created_at timestamptz default now()
);

create table if not exists answers (
  id uuid default uuid_generate_v4() primary key,
  question_id uuid references questions(id) on delete cascade,
  author_id uuid references auth.users,
  text text not null,
  type text check (type in ('ai','human')) default 'human',
  votes int default 0,
  blocked boolean default false,
  created_at timestamptz default now()
);

create table if not exists votes (
  id uuid default uuid_generate_v4() primary key,
  answer_id uuid references answers(id) on delete cascade,
  user_id uuid references auth.users,
  dir int check (dir in (1,-1)),
  unique(answer_id, user_id)
);

create table if not exists tasks (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references auth.users,
  text text not null,
  done boolean default false,
  created_at timestamptz default now()
);

create table if not exists growth (
  user_id uuid references auth.users primary key,
  rings int default 0,
  leaf_positions jsonb default '[]'::jsonb
);

-- trigger: وقتی رأی جدید ثبت/تغییر کرد، ستون votes روی answers آپدیت بشه
create or replace function recalc_answer_votes() returns trigger as $$
begin
  update answers set votes = (
    select coalesce(sum(dir),0) from votes where answer_id = coalesce(new.answer_id, old.answer_id)
  ) where id = coalesce(new.answer_id, old.answer_id);
  return null;
end;
$$ language plpgsql;

drop trigger if exists votes_recalc on votes;
create trigger votes_recalc
after insert or update or delete on votes
for each row execute function recalc_answer_votes();

-- ================= RLS =================
alter table profiles enable row level security;
alter table questions enable row level security;
alter table answers enable row level security;
alter table votes enable row level security;
alter table tasks enable row level security;
alter table growth enable row level security;

-- profiles: هرکس فقط پروفایل خودشو می‌بینه/می‌سازه
create policy "read own profile" on profiles for select using (auth.uid() = id);
create policy "upsert own profile" on profiles for insert with check (auth.uid() = id);
create policy "update own profile" on profiles for update using (auth.uid() = id);

-- questions: همه می‌تونن بخونن؛ فقط کاربر لاگین‌شده می‌تونه بسازه
create policy "public read questions" on questions for select using (true);
create policy "logged users insert questions" on questions for insert with check (auth.uid() = asker_id);

-- answers: همه می‌خونن؛ فقط لاگین‌شده‌ها می‌نویسن (AI از طریق service role رد می‌شه)
create policy "public read answers" on answers for select using (true);
create policy "logged users insert answers" on answers for insert with check (auth.uid() = author_id);

-- votes: هرکس فقط رأی خودشو می‌سازه/عوض می‌کنه
create policy "public read votes" on votes for select using (true);
create policy "logged users vote" on votes for insert with check (auth.uid() = user_id);
create policy "logged users change own vote" on votes for update using (auth.uid() = user_id);
create policy "logged users delete own vote" on votes for delete using (auth.uid() = user_id);

-- tasks: فقط خود کاربر
create policy "own tasks read" on tasks for select using (auth.uid() = user_id);
create policy "own tasks write" on tasks for insert with check (auth.uid() = user_id);
create policy "own tasks update" on tasks for update using (auth.uid() = user_id);
create policy "own tasks delete" on tasks for delete using (auth.uid() = user_id);

-- growth: فقط خود کاربر
create policy "own growth read" on growth for select using (auth.uid() = user_id);
create policy "own growth write" on growth for insert with check (auth.uid() = user_id);
create policy "own growth update" on growth for update using (auth.uid() = user_id);
